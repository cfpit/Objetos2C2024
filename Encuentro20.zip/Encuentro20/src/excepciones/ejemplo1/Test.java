package excepciones.ejemplo1;

public class Test {
    public static void main(String[] args) {
        try {
            System.out.println("Inicio");
            
            Integer.parseInt("Hola Mundo");//se produce exception

        } catch (NumberFormatException e) {
//            e.printStackTrace();
            System.out.println("No podes parsear");
        } finally {
            System.out.println("Sigue...");
        }
        
    }
}
