package excepciones.ejemplo2;

public class Test {

    public static void main(String[] args) {

        try {
            System.out.println("inicio");

//            Integer.parseInt("Hola");
            String palabra = null;
            System.out.println("Longitud = " + palabra.length());
        } catch (NumberFormatException e) {
            System.out.println("Error de parseo");
        } catch (NullPointerException e) {
            System.out.println("Error de puntero a nulo");
        } catch (Exception e) {
            System.out.println("Error");
        } 

        System.out.println("sigue la app...");
    }
}
