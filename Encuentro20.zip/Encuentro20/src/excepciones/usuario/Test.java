package excepciones.usuario;

public class Test {
    public static void main(String[] args) throws NoHayMasPasajesException {
        try {
            Vuelo v = new Vuelo("abc-123", 50);
            
            v.venderPasajes(20);
            v.venderPasajes(5);
            v.venderPasajes(15);
            v.venderPasajes(20);//esta linea lanza exception
            v.venderPasajes(30);
            v.venderPasajes(10);
        } catch (NoHayMasPasajesException e) {
            e.mensajeError();
        }
        
        System.out.println("sigue...");
        
    }
}
