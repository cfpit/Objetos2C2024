package excepciones.usuario;

public class Vuelo {
    private String nombre;
    private int capacidad;

    public Vuelo() {
    }

    public Vuelo(String nombre, int capacidad) {
        this.nombre = nombre;
        this.capacidad = capacidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }
    
    public void venderPasajes(int asientosPedidos) throws NoHayMasPasajesException {
        if (asientosPedidos > this.capacidad) {
            //lanzo manualmente la excepcion de usuario
            throw new NoHayMasPasajesException(nombre, asientosPedidos);
        } else {
            this.capacidad -= asientosPedidos;
        }
    }

    @Override
    public String toString() {
        return "Vuelo{" + "nombre=" + nombre + ", capacidad=" + capacidad + '}';
    }
}
