package ejercicio;

import java.util.Scanner;

public class Ejercicio {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        int [] edades = new int [5];
        
        // variables auxiliares
        int max = 0, total = 0;
        
        //bucle
        
        for (int i = 0; i < edades.length; i++) {
            System.out.println("Ingresa una edad: ");
            edades[i]= lector.nextInt();
            
            //maximo
            if (edades[i] > max) {
                max = edades[i];
            }
            
            //total
//            total = total + edades[i];
            total += edades[i];
        }
        
        System.out.println("maximo = " + max);
        System.out.println("promedio = " + total / edades.length);
        
        System.out.println("--------------------------");
        for (int i = 0; i < edades.length; i++) {
            System.out.println("valor: " + edades[i]);
        }
            
        
        
        
        /*
            comentario
            de
            bloque
        */
        
        
    }
}
