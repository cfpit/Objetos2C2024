package colecciones.listas;

import java.util.ArrayList;
import java.util.Iterator;

public class Test {
    public static void main(String[] args) {
        //creo una lista tipada
        ArrayList<Auto> lista = new ArrayList<>();
        
        //creo 3 autos
        Auto a1 = new Auto("Ford", 30);
        Auto a2 = new Auto("Fiat", 80);
        Auto a3 = new Auto("Renault", 70);
        
        //agrego los autos en la coleccion
        lista.add(a1);
        lista.add(a2);
        lista.add(a3);
        
        System.out.println("Recorro con foreach");
        for (Auto unAuto : lista) {
            if (unAuto.getVelocidad() >= 50) {
                System.out.println(unAuto);
            }
        }
        
        
        System.out.println("Recorro con iterator");
        Iterator it = lista.iterator();
        
        while (it.hasNext()) {
            Auto unAuto = (Auto)it.next();
            if (unAuto.getVelocidad() > 50) {
                System.out.println(unAuto);
            }
        }
        
        
    }
}
