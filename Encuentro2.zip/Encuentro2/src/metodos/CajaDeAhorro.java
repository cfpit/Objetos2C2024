package metodos;

public class CajaDeAhorro {
    //atributos
    public int saldo; 
    public String moneda; 
    
    //constructor vacio
    public CajaDeAhorro() {}
    
    //metodos
    public void informarSaldo() {
        System.out.println("saldo = " + this.saldo);
    }
    
    public void depositar(int monto) {
        this.saldo += monto;
    }
    
    public String extraer(int monto) {
        if (this.saldo > monto) {
            this.saldo -= monto;
            return "Extraccion OK!";
        } else {
            return "Fondos insuficientes";
        }
    }
    
}









