package metodos;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);

        //creo una caja
        CajaDeAhorro cda = new CajaDeAhorro();
        
        //le doy un estado al objeto (es decir, a la caja)
        System.out.println("Ingrese el saldo: ");
        cda.saldo = lector.nextInt();
        
        System.out.println("Ingrese la moneda: ");
        cda.moneda = lector.next();

        //comportamiento
        System.out.println("informar el saldo");
        cda.informarSaldo();
        
        System.out.println("------------------");
        
        System.out.println("Deposito");
        System.out.println("ingrese el monto a depositar: ");
        
        cda.depositar(lector.nextInt());
        
        System.out.println("informar el nuevo saldo");
        cda.informarSaldo();
        
        
        System.out.println("Extraccion");
        System.out.println("ingrese el monto a extraer: ");
        
        System.out.println(cda.extraer(lector.nextInt()));
        
        System.out.println("informar el nuevo saldo");
        cda.informarSaldo();
        
    }
}









