package objetos;

public class Auto {
    //atributos
    public String marca;
    public String color;
    public int velocidad;

    //constructor
    public Auto() {}

    //metodos
    public void acelerar() {
        velocidad += 10;
    }
    
    public void frenar() {
        velocidad -= 5;
    }
    
    
    public static void main(String[] args) {
        Auto a = new Auto();
        Auto b = new Auto();
        System.out.println("marca = " + a.marca);
        System.out.println("velocidad = " + a.velocidad);
        
        a.acelerar();
        b.acelerar();
        
        a.frenar();
        b.frenar();
        
        System.out.println("velocidad de a = " + a.velocidad);
        System.out.println("velocidad de b = " + b.velocidad);
        
    }
}
