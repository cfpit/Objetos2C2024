package polimorfismo;

public class AutoCarrera extends Auto{
    //atributos
    private String escuderia;
    
    //constructores
    public AutoCarrera() {}

    public AutoCarrera(String escuderia, String marca, int velocidad) {
        super(marca, velocidad);
        this.setEscuderia(escuderia);
    }
    
    //getters y setters
    public String getEscuderia() {
        return escuderia;
    }

    public final void setEscuderia(String escuderia) {
        this.escuderia = escuderia;
    }
    
    //metodos
    //polimorfismo sobre el metodo acelerar

    @Override
    public void acelerar() {
        this.velocidad += 50;
    }
    

    @Override
    public String toString() {
        return super.toString() + " escuderia=" + escuderia;
    }
}












