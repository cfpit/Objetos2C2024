package polimorfismo;

public class Test {
    public static void main(String[] args) {
        //creo 2 objetos
        Auto a = new Auto("Ford", 0);
        AutoCarrera ac = new AutoCarrera("Ferrari", "Ferrari", 0);
        
        //comportamiento
        a.acelerar();//0 --> 10
        ac.acelerar();//0 --> 50
        
        //veo el estado final
        System.out.println(a);
        System.out.println("---------------");
        System.out.println(ac);
    }
}
