package colecciones.listas;

import java.util.ArrayList;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        //coleccion no tipada
        ArrayList lista = new ArrayList();
        
        //coleccion tipada
        ArrayList<Persona> lista2 = new ArrayList<>();
        
        List<Persona> lista3 = new ArrayList<>();
        
        //creo objetos de Persona y los agrego a la lista
//        Persona p1 = new Persona("Juan", 25);
//        Persona p2 = new Persona("Maria", 30);
//        Persona p3 = new Persona("Carlos", 20);
//        Persona p4 = new Persona("Ana", 40);
//        
//        lista2.add(p1);
//        lista2.add(p2);
//        lista2.add(p3);
//        lista2.add(p4);

        //guardo en la coleccion objetos anonimos de la clase Persona
        lista2.add(new Persona("Juan", 25));
        lista2.add(new Persona("Maria", 30));
        lista2.add(new Persona("Carlos", 20));
        lista2.add(new Persona("Ana", 40));
        
        
        
        System.out.println("Contenido de la coleccion: " + lista2);
        System.out.println("Longitud: " + lista2.size());
        
        Persona p5 = new Persona("Pedro", 50);
        lista2.add(3, p5);
        System.out.println("Nuevo Contenido de la coleccion: " + lista2);
        
        System.out.println("Recorro con for la coleccion");
        for (int i = 0; i < lista2.size(); i++) {
            Persona unaPersona = lista2.get(i);
            if (unaPersona.getEdad() > 27) {
                System.out.println(unaPersona);
            }
        }
        
        lista2.remove(p5);
        System.out.println("Nuevo Contenido de la coleccion: " + lista2);
        
        
        
    }
}
