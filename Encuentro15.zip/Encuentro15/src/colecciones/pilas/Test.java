package colecciones.pilas;

import java.util.Stack;

public class Test {
    public static void main(String[] args) {
        Stack pila = new Stack();
        
        pila.push("Juan");
        pila.push("Maria");
        pila.push("Carlos");
        pila.push("Ana");
        
        System.out.println("Contenido de la pila: " + pila);
        System.out.println("Longitud: " + pila.size());
        System.out.println("1er elemento a salir: " + pila.peek());
        System.out.println("1er elemento que sale: " + pila.pop());
        
        System.out.println("Nuevo Contenido de la coleccion: " + pila);
        
        System.out.println("Pila vacia?: " + pila.empty());
        
        pila.removeAllElements();
        System.out.println("Y ahora, Pila vacia?: " + pila.empty());
        
        
    }
}
