package colecciones.colas;

import java.util.LinkedList;
import java.util.Queue;

public class Test {
    public static void main(String[] args) {
        Queue cola = new LinkedList();
        
        //ingreso objetos en la coleccion
        cola.add("Juan");
        cola.add("Maria");
        cola.add("Carlos");
        cola.add("Ana");
        
        
        System.out.println("Contenido de la coleccion: " + cola);
        System.out.println("Tamaño de la coleccion: " + cola.size());
        System.out.println("1er elemento a salir: " + cola.peek());
        System.out.println("1er elemento que sale: " + cola.poll());
        
        System.out.println("Nuevo Contenido de la coleccion: " + cola);
        
        
        
    }
}
