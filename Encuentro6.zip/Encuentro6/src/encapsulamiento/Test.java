package encapsulamiento;

public class Test {
    public static void main(String[] args) {
        Auto a1 = new Auto();
        
        //estado inicial
        a1.marca = "Ford";
        a1.color = "Gris";
//        a1.velocidad = 5000;//no se puede por ser privada
        
        a1.setVelocidad(60);
        
        a1.acelerar(150);//se queda en 130
        
        a1.frenar(200);// se queda en 0
        
        //muestro el estado del objeto
//        System.out.println(a1.toString());
        System.out.println(a1);
        
        System.out.println("Color del auto: " + a1.color);
        System.out.println("Velocidad del auto: " + a1.getVelocidad());
        
        
    }
}
