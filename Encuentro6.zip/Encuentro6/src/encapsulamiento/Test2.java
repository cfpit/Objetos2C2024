package encapsulamiento;

public class Test2 {
    public static void main(String[] args) {
        Auto a = new Auto("Honda", "Blanco", 0);
        Auto b = new Auto("Toyota", "Azul", 75000);
        
        a.acelerar();//0 --> 10
        a.acelerar(50);//10 --> 60
        a.acelerar(80);//50 -> 130
        a.acelerar(15);//queda en 130
        
        
        System.out.println(a);
        System.out.println("-----------------");
        System.out.println(b);
    }
}
