package encapsulamiento;

public class Auto {
    //atributos
    public String marca;
    public String color;
    private int velocidad;
    
    //constructores
    //vacio o por defecto
    public Auto() {}
    
    //sobrecargado
    public Auto(String marca, String color, int velocidad) {
        this.marca = marca;
        this.color = color;
//        this.velocidad = velocidad;
        this.setVelocidad(velocidad);
    }
    
    //getters y setters
    public int getVelocidad() {
        return velocidad;
    }

    public final void setVelocidad(int velocidad) {
        //regla de negocio
        if (velocidad >= 0 && velocidad <= 130) 
        {
            this.velocidad = velocidad;
        } 
        else 
        {
            if (velocidad > 130) 
            {
                this.velocidad = 130;
            } 
            else 
            {
                this.velocidad = 0;
            }
        }
    }
    
    
    //metodos
    public void acelerar() {
//        this.velocidad += 10;
        this.setVelocidad(this.velocidad + 10);
    }
    
    public void acelerar(int km) {
//        this.velocidad += km;
        this.setVelocidad(this.velocidad + km);
    }
    
    public void frenar() {
//        this.velocidad -= 5;
        this.setVelocidad(this.velocidad - 5);
    }
    
    public void frenar(int km) {
//        this.velocidad -= km;
        this.setVelocidad(this.velocidad - km);
    }

    
    @Override
    public String toString() {
        return "marca=" + marca + ", color=" + color + ", velocidad=" + velocidad;
    }
    
}
