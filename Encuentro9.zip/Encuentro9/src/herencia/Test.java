package herencia;

public class Test {
    public static void main(String[] args) {
        Vehiculo v = new Vehiculo("avion", 700);
        Avion a = new Avion("Fly Combi", "avion", 500);
        Velero ve = new Velero(20, "velero", 30);
        
        //comportamiento
        a.transportar();
        a.bajarTrenDeAterrizaje();
        
        ve.izarVelas();
        ve.transportar();
        
        //estado
        System.out.println(a);
        System.out.println("-----------------");
        System.out.println(ve);
        
    }
}
