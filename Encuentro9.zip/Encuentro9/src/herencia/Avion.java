package herencia;

import java.util.Arrays;

public class Avion extends Vehiculo{
    //atributos
    private String marca;
    
    //constructores
    public Avion() {}

    public Avion(String marca, String nombre, int velocidad) {
        super(nombre, velocidad);
        this.setMarca(marca);
    }
    
    //getters y setters
    public String getMarca() {
        return marca;
    }

    public final void setMarca(String marca) {
        //regla de negocio
        String [] marcas = {"fly combi","aerolineas"};
        
        if (Arrays.asList(marcas).contains(marca.toLowerCase())) {
            this.marca = marca;
        } else {
            System.out.println("Marca no permitida");
        }
    }
    
    //metodos
    public void bajarTrenDeAterrizaje() {
        System.out.println("Bajo el tren");
    }

    @Override
    public String toString() {
        return super.toString() + " marca=" + marca;
    }
}






