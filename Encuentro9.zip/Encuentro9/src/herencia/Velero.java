package herencia;

public class Velero extends Vehiculo{
    //atributos
    private int eslora;
    
    //constructores
    public Velero() {}

    public Velero(int eslora, String nombre, int velocidad) {
        super(nombre, velocidad);
        this.setEslora(eslora);
    }
    
    //getters y setters
    public int getEslora() {
        return eslora;
    }

    public final void setEslora(int eslora) {
        this.eslora = eslora;
    }
    
    //metodos
    public void izarVelas() {
        System.out.println("izo la vela");
    }

    @Override
    public String toString() {
        return super.toString() + " eslora=" + eslora;
    }
}
