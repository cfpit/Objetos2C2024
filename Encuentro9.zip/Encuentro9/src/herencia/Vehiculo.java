package herencia;

import java.util.Arrays;

public class Vehiculo {
    //atributos
    private String nombre;
    private int velocidad;
    
    //constructores
    public Vehiculo() {}

    public Vehiculo(String nombre, int velocidad) {
        this.setNombre(nombre);
        this.setVelocidad(velocidad);
    }
    
    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public final void setNombre(String nombre) {
        //regla de negocio
        String [] nombres = {"avion","velero"};
        
        if (Arrays.asList(nombres).contains(nombre.toLowerCase())) {
            this.nombre = nombre;
        } else {
            System.out.println("Nombre no permitido");
        }
    }

    public int getVelocidad() {
        return velocidad;
    }

    public final void setVelocidad(int velocidad) {
        //regla de negocio
        if (velocidad >= 0 && velocidad <= 1000) {
            this.velocidad = velocidad;
        } else {
            System.out.println("velocidad fuera de rango");
        }
    }
    
    //metodos
    public void transportar() {
        System.out.println("Tipo de Transporte: " +  this.nombre);
    }
    
    @Override
    public String toString() {
        return "nombre=" + nombre + ", velocidad=" + velocidad;
    }   
}
