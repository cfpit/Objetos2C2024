package palabraStatic;

public class Test { 
    public static void main(String[] args) {
        System.out.println("La velocidad maxima de todos los autos"
                + " fabricados de serie es de " + Auto.velMax + " Km./h.");
        
//        Auto a = new Auto();
//        System.out.println(a.velMax);

        //un atributo estatico puede modificar su valor
        Auto.velMax = 250;
        
        System.out.println("La nueva velocidad maxima de todos los autos es de " 
                + Auto.velMax + " Km./h.");
        
        
    }
}
