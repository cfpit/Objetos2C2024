package palabraFinal;

public class Test {
    public static void main(String[] args) {
        Venta v = new Venta(30000);
        
        System.out.println("Monto con IVA = " 
                + v.getMonto() * v.IVA);
    }
}
