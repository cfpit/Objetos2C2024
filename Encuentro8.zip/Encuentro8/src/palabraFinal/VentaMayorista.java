

package palabraFinal;


public class VentaMayorista extends Venta{
    public String proveedor;
}
