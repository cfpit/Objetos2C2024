package palabraFinal;

//public final class Venta {
public class Venta {
    //atributos
    private int monto;
    public final double IVA = 1.21;//constante -> inicializacion obligatoria 
    
    //constructores
    public Venta() {}

    public Venta(int monto) {
        this.setMonto(monto);
    }
    
    //get y set
    public int getMonto() {
        return monto;
    }

    public final void setMonto(int monto) {
        this.monto = monto;
    }
    
}
