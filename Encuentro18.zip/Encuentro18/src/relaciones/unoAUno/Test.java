package relaciones.unoAUno;

public class Test {
    public static void main(String[] args) {
        Motor m = new Motor(1234, 1600);
        Auto a = new Auto("Ford", "Gris", m);
        
        System.out.println(a);
        System.out.println(m);
        
        
    }
}
