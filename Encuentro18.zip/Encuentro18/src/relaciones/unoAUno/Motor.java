package relaciones.unoAUno;

public class Motor {
    private int nro;
    private int cilindrada;

    public Motor() {
    }

    public Motor(int nro, int cilindrada) {
        this.nro = nro;
        this.cilindrada = cilindrada;
    }

    public int getNro() {
        return nro;
    }

    public void setNro(int nro) {
        this.nro = nro;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return "Motor{" + "nro=" + nro + ", cilindrada=" + cilindrada + '}';
    }
}
