package encapsulamiento;

public class Test2 {
    public static void main(String[] args) {
        //creo una persona con el constructor parametrizado
//        Persona p = new Persona("Maria", 20);
        Persona p = new Persona("Maria", 129);
        
        p.saludar();
        p.cumplirAños();
        p.cumplirAños();
        
        System.out.println(p);
    }
}
