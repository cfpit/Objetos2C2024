package encapsulamiento;

import java.util.Arrays;

public class Persona {
    
   //atributos
    private String nombre;
    private int edad;
    
    //constructores
    public Persona() {}

    public Persona(String nombre, int edad) {
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    //getters y setters
    public int getEdad() {
        return edad;
    }

    public final void setEdad(int edad) {
        //regla de negocio
        if (edad >= 0 && edad <= 130) {
            this.edad = edad;
        } else {
            System.out.println("Edad fuera de rango");
        }
    }


    public String getNombre() {
        return nombre;
    }

    public final void setNombre(String nombre) {
        //regla de negocio
        String [] nombres = {"juan","pedro","maria","ana"};
        
        if (Arrays.asList(nombres).contains(nombre.toLowerCase())) {
            this.nombre = nombre;
        } else {
            System.out.println("Nombre no permitido");
        }
    }
    
    //metodos
    public void saludar() {
        System.out.println("Hola!, soy una persona!!");
    }
    
    public void cumplirAños() {
//        this.edad += 1;
        this.setEdad(this.edad + 1);
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;    
    }

}
