package encapsulamiento;

public class Test {
    public static void main(String[] args) {
        //creo una persona con el constructor vacio
        Persona p = new Persona();
        
        //defino el estado inicial
        p.setNombre("Juan");
//        p.setEdad(300);
        p.setEdad(30);
        
        //comportamiento
        p.saludar();
        p.cumplirAños();
        
        //muestro el estado
//        System.out.println(p.toString());
        System.out.println(p);
        
        
    }
}
