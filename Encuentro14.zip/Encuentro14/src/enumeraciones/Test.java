package enumeraciones;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        System.out.println("Decime que dia es hoy?: ");
        String diaHoy = lector.next();
        
        if (diaHoy.toUpperCase().equals(String.valueOf(Dia.LUNES))) 
        {
            System.out.println("Hoy arranca la semana!");
        } 
        else 
        {
            if (diaHoy.toUpperCase().equals(String.valueOf(Dia.VIERNES))) 
            {
                System.out.println("Se viene el finde!");
            } 
            else 
            {
                System.out.println("Hoy es un dia cualquiera");
            }
        }
    }
}
