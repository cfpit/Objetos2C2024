package comparacion;

import java.util.Objects;

public class Persona {
    private String nombre;
    private int edad;

    public Persona() {}

    public Persona(String nombre, int edad) {
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    //redefinimos los metodos equals y hashCode

    @Override
    public int hashCode() {
        return Objects.hash(nombre,edad);
    }

    @Override
    public boolean equals(Object obj) {
        //casteo el tipo de dato(de Object a Persona)
        Persona p =(Persona)obj;
        
        if (this.getNombre().equals(p.getNombre()) && this.getEdad() == p.getEdad()) {
            return  true;
        } else {
            return false;
        }
    }
    

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }
}
