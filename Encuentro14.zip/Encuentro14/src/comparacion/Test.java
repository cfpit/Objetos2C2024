package comparacion;

public class Test {
    public static void main(String[] args) {
        //CASO 1
//        Persona p1 = new Persona("Juan", 25);
//        Persona p2 = new Persona("Maria", 30);
        
        //CASO 2
//        Persona p1 = new Persona("Juan", 25);
//        Persona p2 = new Persona("Juan", 25);
        
        //CASO 3
        Persona p1 = new Persona("Juan", 25);
        Persona p2 = p1;
        
        
        //referencias
        if (p1 == p2) {
            System.out.println("igual referencia");
        } else {
            System.out.println("diferente referencia");
        }
        
        
        //contenidos
        if (p1.equals(p2)) {
            System.out.println("igual contenido");
        } else {
            System.out.println("diferente contenido");
        }
        
        System.out.println("---------------");
        
        System.out.println("codigo hash p1: " + p1.hashCode());
        System.out.println("codigo hash p2: " + p2.hashCode());
    }
}
