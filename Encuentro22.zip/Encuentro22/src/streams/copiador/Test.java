package streams.copiador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        //src/streams/copiador/archivoOrigen.txt
        try {
            File origen = new File("src/streams/copiador/archivoOrigen.txt");
            File destino = new File("src/streams/copiador/archivoDestino.txt");
            
            BufferedReader lector = new BufferedReader(new FileReader(origen));
            BufferedWriter escritor = new BufferedWriter(new FileWriter(destino));

            //algoritmo de copia
            String lineaLeida = "";
            while ((lineaLeida = lector.readLine()) != null) {
                escritor.write(lineaLeida);
                escritor.newLine();
            }
            
            System.out.println("Archivo copiado...");
            
            lector.close();
            escritor.close();
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado");
        } catch (IOException e) {
            System.out.println("Error de IO");
        }
        
        
        
    }
}
