package streams.copiadorBinario;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try {
            File origen = new File("src/streams/copiadorBinario/paisaje.jpg");
            File destino = new File("src/streams/copiadorBinario/clon.jpg");
            
            FileInputStream lector = new FileInputStream(origen);
            FileOutputStream escritor = new FileOutputStream(destino);

            //algoritmo de copia
            int unByte;
            while ((unByte = lector.read()) != -1) {
                escritor.write(unByte);
            }
            
            System.out.println("Archivo copiado...");
            
            lector.close();
            escritor.close();
        } catch (IOException iOException) {
        }
        
        
    }
}
