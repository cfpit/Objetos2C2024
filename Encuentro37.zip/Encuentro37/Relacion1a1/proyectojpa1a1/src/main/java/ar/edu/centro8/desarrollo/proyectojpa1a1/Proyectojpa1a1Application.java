package ar.edu.centro8.desarrollo.proyectojpa1a1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyectojpa1a1Application {

	public static void main(String[] args) {
		SpringApplication.run(Proyectojpa1a1Application.class, args);
	}

}
		