package ar.edu.centro8.desarrollo.proyectojpa1a1.services;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ar.edu.centro8.desarrollo.proyectojpa1a1.models.Auto;
import ar.edu.centro8.desarrollo.proyectojpa1a1.models.Motor;
import ar.edu.centro8.desarrollo.proyectojpa1a1.repositories.IAutoRepository;
import jakarta.transaction.Transactional;

import java.util.List;

@Service
@Transactional
public class AutoService implements IAutoService {
    @Autowired
    private IAutoRepository autoRepo;
    
    @Override
    public List<Auto> obtenerAutos() {
        List<Auto> listaPersonas = autoRepo.findAll();
        return listaPersonas;
    }

    
    @Override
    public Auto guardarAuto(Auto auto) {
        autoRepo.save(auto);
        return auto;
    }

    @Override
    public boolean eliminarAuto(Long id) {
        try {
            autoRepo.deleteById(id);
            return true; // El auto se eliminó con éxito
        } catch (Exception e) {
            return false; // No se pudo eliminar el auto
        }
    }

    @Override
    public Auto traerAuto(Long id) {
        Auto perso = autoRepo.findById(id).orElse(null);
        return perso;
    }

    @Override
    public Auto editarAuto(Long idOriginal, Long idNueva, String nuevaMarca, BigDecimal nuevoPrecio) {
        //busco  el objeto original
        Auto auto = this.traerAuto(idOriginal);
            
        //proceso de modificación a nivel lógico
        auto.setIdAuto(idNueva);
        auto.setMarca(nuevaMarca);
        auto.setPrecio(nuevoPrecio);
        
        //guardar los cambios
        this.guardarAuto(auto);

        return auto;
    }

    
}

    

