package ar.edu.centro8.desarrollo.proyectojpa1a1.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import ar.edu.centro8.desarrollo.proyectojpa1a1.models.Auto;
import ar.edu.centro8.desarrollo.proyectojpa1a1.services.AutoService;

import java.util.List;

@RestController
@RequestMapping("/api/autos")
public class AutoController {
    @Autowired
    private AutoService autoService;

    @GetMapping
    public List<Auto> getAllAutos() {
        return autoService.obtenerAutos();
    }

    @GetMapping("/{id}")
    public Auto getAutoById(@PathVariable Long id) {
        return autoService.traerAuto(id);
    }

    @PostMapping
    public void createAuto(@RequestBody Auto auto) {
        autoService.guardarAuto(auto);
    }


    @PutMapping("/{id}")
    public void updateAuto(@PathVariable Long id, @RequestBody Auto auto) {
         autoService.editarAuto(id,auto.getIdAuto(),auto.getMarca(),auto.getPrecio());
    }

    @DeleteMapping("/{id}")
    public void deleteAuto(@PathVariable Long id) {
        autoService.eliminarAuto(id);
    }  

}

