package ar.edu.centro8.desarrollo.proyectojpa1a1.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "motor")
@Getter @Setter
@NoArgsConstructor
public class Motor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idMotor;

    @Column(name = "cilindrada", nullable = false)  
    private Integer cilindrada;

    public Motor(Integer cilindrada) {
        this.cilindrada = cilindrada;
    }

    //RELACION UNIDIRECCIONAL: sin codigo

}
