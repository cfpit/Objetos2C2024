package colecciones.generics;

import java.util.ArrayList;


public class Generica<T> {
    ArrayList<T> lista = new ArrayList<>();
    
    //metodos delegados
    public int tamaño() {
        return lista.size();
    }

    public T obtener(int index) {
        return lista.get(index);
    }

    public boolean agregar(T e) {
        return lista.add(e);
    }

    public T eliminar(int index) {
        return lista.remove(index);
    }
    
}
