package colecciones.generics;


public class Test {
    public static void main(String[] args) {
        Generica g = new Generica();
        
//        g.agregar("Juan");
//        g.agregar("Maria");
//        g.agregar("Carlos");
//        g.agregar("Ana");
//        
//        System.out.println(g.tamaño());
//        System.out.println(g.obtener(3));
//        System.out.println(g.eliminar(2));
//        
//        System.out.println(g.lista);
        
        
//        g.agregar(10);
//        g.agregar(20);
//        g.agregar(50);
//        g.agregar(40);
//        
//        System.out.println(g.tamaño());
//        System.out.println(g.obtener(3));
//        System.out.println(g.eliminar(2));
//        
//        System.out.println(g.lista);


        g.agregar(new Persona("Juan", 25));
        g.agregar(new Persona("Maria", 30));
        g.agregar(new Persona("Carlos", 40));
        g.agregar(new Persona("Ana", 20));
        
        
        System.out.println(g.tamaño());
        System.out.println(g.obtener(3));
        System.out.println(g.eliminar(2));
        
        System.out.println(g.lista);
        
        
        
    }
}
