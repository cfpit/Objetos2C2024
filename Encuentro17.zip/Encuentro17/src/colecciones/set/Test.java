package colecciones.set;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;


public class Test {
    public static void main(String[] args) {
        HashSet<String> lista = new HashSet<>();//no ordena segun ingreso
        LinkedHashSet<String> lista2 = new LinkedHashSet<>();
        TreeSet<String> lista3 = new TreeSet<>();
        TreeSet<Persona> lista4 = new TreeSet<>();
        
        lista.add("Juan");
        lista.add("Maria");
        lista.add("Carlos");
        lista.add("Ana");
        lista.add("Ana");//evita duplicados por ser set
        
        System.out.println(lista);
        
        lista2.add("Juan");
        lista2.add("Maria");
        lista2.add("Carlos");
        lista2.add("Ana");
        lista2.add("Ana");//evita duplicados por ser set
        
        System.out.println(lista2);
        
        lista3.add("Juan");
        lista3.add("Maria");
        lista3.add("Carlos");
        lista3.add("Ana");
        lista3.add("Ana");//evita duplicados por ser set
        
        System.out.println(lista3);
        
        Persona p1 = new Persona("Juan", 25);
        Persona p2 = new Persona("Maria", 40);
        Persona p3 = new Persona("Carlos", 30);
        Persona p4 = new Persona("Ana", 20);
        
        lista4.add(p1);
        lista4.add(p2);
        lista4.add(p3);
        lista4.add(p4);
        
        System.out.println(lista4);
        
        
        
        
    }
            
}
