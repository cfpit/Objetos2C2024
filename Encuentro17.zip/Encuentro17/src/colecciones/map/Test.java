package colecciones.map;


import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class Test {
    public static void main(String[] args) {
        HashMap<String,String> mapa = new HashMap<>();
        LinkedHashMap<String,String> mapa2 = new LinkedHashMap<>();
        TreeMap<String,String> mapa3 = new TreeMap<>();
        
        mapa.put("rojo", "red");
        mapa.put("azul", "blue");
        mapa.put("verde", "green");
        mapa.put("blanco", "white");
        
        System.out.println(mapa);
        System.out.println(mapa.values());
        System.out.println(mapa.keySet());
        System.out.println(mapa.get("rojo"));
        System.out.println(mapa.getOrDefault("amarillo", "no existe"));
        
        
        mapa2.put("rojo", "red");
        mapa2.put("azul", "blue");
        mapa2.put("verde", "green");
        mapa2.put("blanco", "white");
        System.out.println(mapa2);
        
        
        mapa3.put("rojo", "red");
        mapa3.put("azul", "blue");
        mapa3.put("verde", "green");
        mapa3.put("blanco", "white");
        System.out.println(mapa3);
        
        
        
        
        
        
        
    }
}
