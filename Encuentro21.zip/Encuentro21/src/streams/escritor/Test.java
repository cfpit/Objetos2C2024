package streams.escritor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        try {
            File archivo = new File("src/streams/escritor/archivo.txt");
            
            BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo));

            //armo la info a escribir en el archivo
            //Si el archivo no existe, se crea
            //Si el archivo existe, se pisa con el nuevo contenido
            String linea1 = "Hola, soy ltr{´nñ.tgfn,ga linea 1";
            String linea2 = "Hola, yo soy la linea 2";
            String linea3 = "y yo la linea 3";
            
            escritor.write(linea1);
            escritor.newLine();//salto de linea
            escritor.write(linea2);
            escritor.newLine();
            escritor.write(linea3);
            escritor.newLine();
            
            escritor.append("esto es un agregado\n");
            escritor.append("esto es otro agregado\n");
            
            System.out.println("Archivo escrito...");
            
            escritor.close();
        } catch (IOException e) {
            System.out.println("error de escritura");
        }
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
