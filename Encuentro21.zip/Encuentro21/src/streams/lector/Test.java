package streams.lector;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
//        src/streams/lector/archivo.txt
    
        try {
            //creo un objeto File que tiene la ruta(path) del archivo que se lee
            File archivo = new File("src/streams/lector/archivo.txt");

            //creo un stream que lee de a lineas el archivo de texto
            BufferedReader lector = new BufferedReader(new FileReader(archivo));

            //algoritmo de lectura
            //variables auxiliares
            String lineaLeida = "";
            boolean eof = false;//flag o bandera o indicador de fin de archivo

            //mientras no se termine el archivo de leer...
            while (!eof) {
                //...entonces leo e imprimo...
                lineaLeida = lector.readLine();
                if (lineaLeida != null) {
                    System.out.println(lineaLeida);
                } else {
                    //...sino, cambio el flag para salir del bucle de lectura
                    eof = true;
                }
            }

            //una vez terminada la lectura, cierro el stream por seguridad
            lector.close();
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado");
        } catch (IOException e) {
            System.out.println("Error de lectura");
        }
        
    }
}
