-- selecciono la base x defecto
use pubs;

-- veo la estructura de una tabla
describe authors;

-- veo las tablas de la base
show tables;

-- queries
select * from titles;

select 	title titulo, 
		type as categoria,
        price as precio
from 	titles
-- where	price >= 10 and price <= 20;
-- where	price between 10 and 20;
where	not price between 10 and 20;

select 	* 
from 	jobs
where	job_desc in ('publisher','editor','designer');

-- listar el nombre de las editoriales que hayan publicado
-- libros de cocina
select 		p.pub_name editorial,
			t.title titulo,
			t.type categoria
from		titles t
inner join	publishers p
on			p.pub_id = t.pub_id
where		t.type like '%cook%';

use negocio;
describe productos;
select * from productos;

insert into productos 
values(11,'pantuflas',20,'Salada',50,'negro','m');

select * from productos;

update 	productos 
set		precio = precio * 1.2
where	articulo like '%pantalon%';

select * from productos;

delete from productos
where	articulo = 'gorra';

select * from productos;

        
        








