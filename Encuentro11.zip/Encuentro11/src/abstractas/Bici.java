package abstractas;

public class Bici extends Vehiculo {

    //atributos
    private int rodado;

    //constructores
    public Bici() {
    }

    public Bici(int rodado, int velocidad) {
        super(velocidad);
        this.setRodado(rodado);
    }

    //getters y setters
    public int getRodado() {
        return rodado;
    }

    public void setRodado(int rodado) {
        this.rodado = rodado;
    }

    //metodos
    //implemento el metodo abstracto acelerar del padre
    public void acelerar() {
//        this.velocidad += 5;
        this.setVelocidad(velocidad + 5);
    }
    
        public void setVelocidad(int velocidad) {
            if (velocidad >= 0 && velocidad <= 60) {
                this.velocidad = velocidad;
            } else {
                System.out.println("Velocidad bici mal");
            }
    }

    @Override
    public String toString() {
        return super.toString() + " rodado=" + rodado;
    }
}
