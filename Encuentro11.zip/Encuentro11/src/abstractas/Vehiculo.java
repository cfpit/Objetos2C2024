package abstractas;

public abstract class Vehiculo {
    //atributos
    protected int velocidad;
    
    //constructores
    public Vehiculo() {}

    public Vehiculo(int velocidad) {
        this.setVelocidad(velocidad);
    }
    
    //getters y setters

    public int getVelocidad() {
        return velocidad;
    }

//    public void setVelocidad(int velocidad) {
//        this.velocidad = velocidad;
//    }
    public abstract void setVelocidad(int velocidad);
    
    //metodos
    //metodo abstracto acelerar
    public abstract void acelerar();
    

    @Override
    public String toString() {
        return "velocidad=" + velocidad;
    }
}
