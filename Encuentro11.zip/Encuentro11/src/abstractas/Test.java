package abstractas;

public class Test {
    public static void main(String[] args) {
        //no puedo instanciar un vehiculo x ser abstracta
//        Vehiculo v = new Vehiculo();

        //creo un avion y una bici
//        Avion a = new Avion("Fly Combi", 700);
//        Bici b = new Bici(28, 10);
        
        Avion a = new Avion("Fly Combi", 1101);
        Bici b = new Bici(28, 56);
        
        //comportamiento
        a.acelerar();
        b.acelerar();
        
        //estado
        System.out.println("Avion:  " +  a);
        System.out.println("Bici:  " +  b);
    }
}
