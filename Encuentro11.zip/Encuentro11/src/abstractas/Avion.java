package abstractas;

public class Avion extends Vehiculo{
    
    //atributos
    private String aerolinea;
    
    //constructores
    public Avion() {}

    public Avion(String aerolinea, int velocidad) {
        super(velocidad);
        this.aerolinea = aerolinea;
    }
    
    //getters y setters

    public String getAerolinea() {
        return aerolinea;
    }

    public void setAerolinea(String aerolinea) {
        this.aerolinea = aerolinea;
    }
    
    //metodos
    //implemento el metodo abstracto acelerar del padre
    @Override
    public void acelerar() {
        this.setVelocidad(velocidad + 100);
    }
    
    @Override
        public void setVelocidad(int velocidad) {
            if (velocidad >= 0 && velocidad <= 1200) {
                this.velocidad = velocidad;
            } else {
                System.out.println("Velocidad avion mal");
            }
        }
    
    

    @Override
    public String toString() {
        return super.toString() + " aerolinea=" + aerolinea;
    }
}
