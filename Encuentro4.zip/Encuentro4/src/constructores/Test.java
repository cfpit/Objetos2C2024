package constructores;

public class Test {
    public static void main(String[] args) {
        //creo una persona usando el constructor vacio
        Persona p1 = new Persona();
        
        //creo otra persona usando el constructor parametrizado
        Persona p2 = new Persona("Juan", "Perez", 25);
        
        //comportamiento
        p1.saludar();
        p2.saludar();
    }
}
