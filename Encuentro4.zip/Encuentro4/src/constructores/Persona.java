package constructores;

public class Persona {
    //atributos
    public String nombre;
    public String apellido;
    public int edad;
    
    //constructor vacio
    public Persona() {}
    
    //sobrecarga de constructor con 2 parametros
    public Persona(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }
    
    //sobrecarga de constructor con 3 parametros
    public Persona(String nombre, String apellido, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }
    
    //metodos
    public void saludar() {
        System.out.println("Hola!, soy " + this.nombre + " y tengo " +
                  this.edad + " años");
    }

}
