package relaciones.unoAMuchos;

import java.util.ArrayList;
import java.util.List;

public class Concesionaria {
    private String nombre;
    private List<Auto> autos;

    public Concesionaria() {
    }

    public Concesionaria(String nombre) {
        this.nombre = nombre;
        autos = new ArrayList<>();
    }
    
    //delegado
    public boolean agregar(Auto e) {
        return autos.add(e);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Auto> getAutos() {
        return autos;
    }

    public void setAutos(List<Auto> autos) {
        this.autos = autos;
    }

    @Override
    public String toString() {
        return "Concesionaria{" + "nombre=" + nombre + ", autos=" + autos + '}';
    }
}
