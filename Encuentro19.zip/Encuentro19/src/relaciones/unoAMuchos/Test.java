package relaciones.unoAMuchos;

public class Test {
    public static void main(String[] args) {
        Concesionaria c = new Concesionaria("Auto Latina SA");
        
        Auto a1 = new Auto("Ford", "Gris");
        Auto a2 = new Auto("Chevrolet", "Azul");
        Auto a3 = new Auto("Fiat", "Blanco");
        
        //agrego los autos a la concesionaria a traves 
        //del metodo delegado
        c.agregar(a1);
        c.agregar(a2);
        c.agregar(a3);
        
        System.out.println(c);
        
    }
}
