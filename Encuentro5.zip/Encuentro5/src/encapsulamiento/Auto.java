package encapsulamiento;

public class Auto {
    //atributos
    public String marca;
    public String color;
    private int velocidad;
    
    //constructores
    //vacio o por defecto
    public Auto() {}
    
    //sobrecargado
    public Auto(String marca, String color, int velocidad) {
        this.marca = marca;
        this.color = color;
        this.velocidad = velocidad;
    }
    
    //getters y setters
    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        //regla de negocio
        if (velocidad >= 0 && velocidad <= 130) {
            this.velocidad = velocidad;
        } else {
            System.out.println("Velocidad fuera de rango");
        }
    }
    
    
    //metodos
    public void acelerar() {
        this.velocidad += 10;
    }
    
    public void acelerar(int km) {
        this.velocidad += km;
    }
    
    public void frenar() {
        this.velocidad -= 5;
    }
    
    public void frenar(int km) {
        this.velocidad -= km;
    }

    
    @Override
    public String toString() {
        return "marca=" + marca + ", color=" + color + ", velocidad=" + velocidad;
    }
    
}
