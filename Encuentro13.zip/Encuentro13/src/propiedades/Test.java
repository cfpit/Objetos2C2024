package propiedades;

public class Test {
    public static void main(String[] args) {
        System.out.println("Propiedades: " + System.getProperties());
        
        System.out.println("------------------------------------");
        
        System.out.println("Version de Java: " + System.getProperty("java.version"));
        
        System.out.println("Sistema Operativo: " + System.getProperty("os.name"));
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
